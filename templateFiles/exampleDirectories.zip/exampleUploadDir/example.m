clc()
clearvars();
close all;

%nWorker = 4;
nFor = 4;
nBench = 1;

%myPool = parpool(nWorker);
tic();
myPool = gcp;
poolSize = myPool.NumWorkers;
nFor = poolSize;
ParPoolStartTime = toc();

tic();
ergebnis = cell(nFor, 1);
parfor i=1:nFor
    ergebnis{i, 1} = bench(nBench);
end
ParForTime = toc();

save('results/result');
delete(myPool);

